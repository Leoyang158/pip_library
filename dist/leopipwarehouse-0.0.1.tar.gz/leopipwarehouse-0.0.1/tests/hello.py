from leonewworld import example
print(example.add_one(2))